#! /bin/sh

./configure \
--with-moduledir=/lib/modules/3.8.0-29-generic/misc \
--with-tty=/dev/ttyACM0 \
--without-x \
--enable-debug \
--enable-dyncodes \
--with-driver=usb_irtoy \
--with-port=none \
--with-irq=none \
"$@"
